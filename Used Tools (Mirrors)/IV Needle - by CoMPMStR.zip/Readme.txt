
-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-
 IV Needle
-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-
 Version 1.5.1
 (2/11/2009)
-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-
 Created by: CoMPuTer MAsSteR [.:AKA:.] CoMPMStR



-+-+-+-+-+-+-
 DISCLAMER!
-+-+-+-+-+-+-

This program is freeware and can be distributed freely, as long as this file, Readme.txt, is included and no changes are made to any files distributed with this file; including this file.

I take no responsibility of any damages caused by using this program!



-+-+-+-+-+-+-+-+-+-+-
 Brief Instructions
-+-+-+-+-+-+-+-+-+-+-

IV Needle is a tool designed to help modify text-based data files in GTAIV. It's a compilation of all my individual editors. Each of the editors in IV Needle will retain all functions in their individual counterparts, but the individual editors will no longer be updated. It will be much easier for me to update one large program rather than updating multiple smaller programs.

The tools contained herein are as follows:
 - Mod Assistant {v1.7}
Mod Assistant is designed to allow modification of your PC installation of GTAIV. It handles all the dirty work like patching filelist.pak, modifying files.txt, backing up files, and even properly setting the files' ReadOnly status to allow for quick and easy modding. It will also detect any invalid files using the same method as the game itself and supports all game versions to date.

 - Handling Editor {v1.8}
Handling Editor is designed to allow full control of all the vehicles' handling data. It allows you to set individual attributes to each vehicle one by one, or set an attribute to all vehicles at once. You can also choose to import or export your vehicle's handling data to share with others or backup for personal use later.

 - Weapon Editor {v1.5}
Weapon Editor is designed to allow easy modification of all the weapons available in the game. It gives you a wide array of options to edit, which can lead to adding more fun to the game. No need to worry about changing something incorrectly, the game simply doesn't allow you to use the bad weapon indicating an error that needs fixing.

 - iDE Editor {v0.4 BETA}
iDE Editor is designed to allow you to edit some of the various game's item definition files. It allows you to change values that determine how certain peds and vehicles behave. You're also given the ability to edit various objects and other data defined for the different areas.

 - Vehicle Group Editor {v1.2}
Vehicle Group Editor is designed to allow some modification of the vehicle groups specified for each area. You can add individual vehicles to any specific area or add multiple vehicles to all areas, the choice is yours.

 - Vehicle Colors Editor {v1.3}
Vehicle Colors Editor is designed to give you access to all of the vehicle colors and vehicle color schemes defined in the file. You can add new colors and color schemes, or even edit and remove existing colors and color schemes. You can even view the color index table to allow for even easier color scheme decisions.

 - Ped Personality Editor {v1.1}
Ped Personality Editor is designed to allow editing of all pedestrian personality data. It seems that the game doesn't rely much on this data so many changes you make may not affect the game the way you envision.

 - Ped Group Editor {v1.2}
Ped Group Editor is designed to allow modifications to the pedestrian groups specified for each area. You can add individual peds to any specific area or add multiple peds to all areas.

 - Popcycle Editor {v1.1}
Popcycle Editor is designed to allow modifying all of the popcycle data. Popcycle data defines how many peds, cars, cops, gang members, etc. are in each area during a certain time.

 - Explosion FX Editor {v1.1}
Explosion FX Editor is designed to allow you to modify all of the explosion effects data. This data defines the damage, light color, force, and other properties of the different explosion types.

 - Relationship Editor {v1.0}
Relationship Editor is designed to allow changes in the relationships between the different ped types. You can set whether a certain ped type respects, likes, dislikes, or hates another ped type.

 - Timecyc Editor {v0.1 BETA}
Timecyc Editor is designed to give you control over the way the game looks at different times of the day in different weather conditions. This data defines the way the sky, clouds, sun, and water appear visually, plus more.

 - Scenarios Editor {v1.0}
Scenarios Editor is designed to allow editing of the different ped scenarios that take place. You can edit the time they're available, how many peds that are used, and other properties. You're also able to edit which models to exclude from the scenario, if any.


NOTE: If you believe an editor should support a specific feature, or if you would like to see a certain editor available, let me know. I try to add as much as I can think of, but I can only think of so much.



-+-+-+-+-
 .F.A.Q.
-+-+-+-+-

 Q.) Why do I get an "Access to the path <filename> is denied." error message when I try to save a file?
 A.) This is because the file is still set as Read-only.

 Q.) Why doesn't my game launch after I save the file I'm editing?
 A.) This is because you haven't used my Mod Assistant, or similar, to allow modifications.



-+-+-+-+-
 History
-+-+-+-+-

Version 1.0 (1/4/2009)
 - First Public Release.
 - Removed the 'Backup' and 'Restore' buttons in the Mod Assistant. Now you right click on the lists to show the respective menus.
 - Removed the 'Open in Notepad' button in the Mod Assistant. Simply double click the item to open the file in notepad.
 - Fixed a bug in the Mod Assistant that may cause some people to get an IndexOutOfRange exception after loading files.txt.
 - Added a new function to the Handling Editor. Now you can add or remove extended data for any vehicle.
 - Changed loading and saving functions for the Weapon Editor. Now it automatically loads and saves the additional files, ThrownWeaponInfo.xml and MeleeAnims.dat.
 - Added a new function to the Weapon Editor. Now you can add new weapons or remove existing weapons.
 - Added a new option to the iDE Editor. Now you can choose whether to load the various map *.ide files or not.

Version 1.1 (1/5/2009)
 - Fixed a small bug in the Vehicle Group Editor.
 - Added a new editor, Ped Group Editor.
 - Added a new editor, Popcycle Editor.

Version 1.2 (1/7/2009)
 - Improved all editors a bit.
 - Added a new feature to the Mod Assistant. You can now restore files from a *.masp service pack file.
 - Fixed a bug in the Handling Editor when launching the flags editor.
 - Fixed a bug in the Weapon Editor not saving the files correctly for some people.
 - Fixed a small stupid bug in the iDE Editor peds loading function.
 - Added a new editor, Explosion FX Editor.

Version 1.3 (1/9/2009)
 - Fixed the properties in the Handling Editor. Now all data properties should be displayed correctly.
 - Fixed the properties in the Vehicle Colors Editor. Now all Car4 data properties should be displayed correctly.
 - Added a new function to the Ped Personality Editor. Now you can apply the current sub flags to all peds.
 - Fixed a bug in the Ped Group Editor when adding peds to an empty group.
 - Fixed a bug in the Ped Group Editor adding ped models already in the group.
 - Added a new editor, Relationship Editor.

Version 1.4 (1/11/2009)
 - Fixed a minor bug in the Handling Editor's Set All feature. Now it should work correctly, again.
 - Added a new editor, Timecyc Editor.

Version 1.4.1 (1/13/2009)
 - Improved the Handling Editor's Set All feature a bit more.
 - Added multiply and divide to the Handling Editor's Set All feature.

Version 1.4.2 (1/14/2009)
 - Fixed a bug in the Mod Assistant upon loading the files.txt for people who installed to a location other than the default.

Version 1.4.3 (1/21/2009)
 - Added a customizable main menu. Right click on the main image to switch to and from list display and icon display.
 - Fixed some minor bug in the Mod Assistant not restoring files using a different extension than modbak.
 - Fixed a bug in the Handling Editor's Set All feature. It shouldn't change . to , anymore.
 - Added a missing property in the Weapon Editor. Now you can modify the rate of fire for the weapons.
 - Removed the cutscene models from the ped group editor. They may appear incorrectly if spawned ingame.

Version 1.4.4 (1/30/2009)
 - Updated the Mod Assistant to work for game version v1.0.2.0. Even though modifying files.txt is not needed it can still be used to patch filelist.pak, set all files ReadOnly status to false, and you can still use the service pack feature if you completely screw up a file.

Version 1.5 (2/2/2009)
 - Now will allow multiple instances of the program to be run.
 - Fixed a minor bug in the Mod Assistant.
 - Added the Set All feature to the Popcycle Editor. It's available in the edit window.
 - Added a new editor, Scenarios Editor.

Version 1.5.1 (2/11/2009)
 - Fixed a bug in the Explosion FX editor which caused errors for some people upon loading the file.



-+-+-+-+-+-+-+-+--+-+-+-+-+-+-+-+-+-+-+-
 Mod Assistant Service Packs (51.29 MB)
-+-+-+-+-+-+-+-+--+-+-+-+-+-+-+-+-+-+-+-

MASP [Game Version 1.0.0.0] - http://www.megaupload.com/?d=I7BWHK9X (Thanks to Costar)
MASP [Game Version 1.0.1.0] - http://www.sendspace.com/file/10axgt
MASP [Game Version 1.0.2.0] - http://www.sendspace.com/file/7rx50g



-+-+-+-+-+-+-+-+-
 Known Problems
-+-+-+-+-+-+-+-+-

If you find any, let me know.



-+-+-+-+-
 Contact
-+-+-+-+-

If you have any comments, questions, problems or anything else regarding this software:
 - Email: computermasster[at]gmail[dot]com
								~EOF~